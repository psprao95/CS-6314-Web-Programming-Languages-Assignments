$(document).ready(function()
{

  $.ajax({
     type:"GET",
    url: "movies.xml",
		 dataType: "xml",

		 success: function(data)
     {
            $(data).find("movie").each(function()
            {
              var title= $(this).find("title").text();
              var genre="";
              $(this).find("genre").each(function()
              {
                genre+= ','+$(this).text();
              }
              var mpaa= $(this).find("mpaa-rating").text();
              var director= $(this).find("director").text();
              var cast="";
              $(this).find("person").each(function()
              {
                cast+=","+$(this).text();
              }
              var synopsis=$(this).find('synopsis').text();
            });
            $("#dvcontent").append('Title: ' + title + 'Genre: ' + genre + 'MPAA rating:' + mpaa + 'Director: ' + director + 'Cast: ' + cast + 'Synopsis: ' +synopsis);

     },
     error:function()
     {
       alert('something went wrong loading the xml file');
     }
   });
});
